# License

Read the license here: [shipsaas.com/license](https://shipsaas.com/license)
