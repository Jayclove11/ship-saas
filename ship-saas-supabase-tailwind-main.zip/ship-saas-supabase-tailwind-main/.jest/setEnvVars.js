// set mock environment variables for tests

process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://a-mock-url.com'
process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = 'a-mock-key'
process.env.SUPABASE_SERVICE_ROLE_KEY = 'a-mock-key'
