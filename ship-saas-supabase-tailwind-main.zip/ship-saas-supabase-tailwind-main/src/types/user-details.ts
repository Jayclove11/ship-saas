export type UserDetails = {
  id: string
  full_name: string
  avatar_url: string
  billing_address: string
  payment_method: string
}
