export type StripeCustomer = {
  user_id: string
  stripe_customer_id: string
}
