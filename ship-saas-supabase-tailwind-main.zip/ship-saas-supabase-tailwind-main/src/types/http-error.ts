export type HttpError = {
  statusCode: number
  type: string
  message: string
}
