# Ship SaaS Supabase and Tailwindcss boilerplate

Check out the official Ship SaaS docs for the most up to date documentation: [shipsaas.com/docs](https://shipsaas.com/docs)
